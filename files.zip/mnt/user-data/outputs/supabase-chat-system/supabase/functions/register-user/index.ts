// ==========================================
// Supabase Edge Function: register-user
// ==========================================
// 用户注册（带密码加密和聊天记录迁移）
// ==========================================

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import * as bcrypt from 'https://deno.land/x/bcrypt@v0.4.1/mod.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // 创建Supabase Admin客户端（用于创建用户）
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    )

    // 获取请求参数
    const { username, passwordHash, tempId, tempData } = await req.json()

    // 1. 参数验证
    if (!username || !passwordHash) {
      return new Response(
        JSON.stringify({ error: '用户名和密码不能为空' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    if (username.length < 2 || username.length > 20) {
      return new Response(
        JSON.stringify({ error: '用户名长度必须在2-20位之间' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // 用户名格式检查
    if (!/^[\u4e00-\u9fa5a-zA-Z0-9]+$/.test(username)) {
      return new Response(
        JSON.stringify({ error: '用户名只能包含中文、字母和数字' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // 2. 检查用户名是否已存在
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('username', username)
      .single()

    if (existingUser) {
      return new Response(
        JSON.stringify({ error: '用户名已存在' }),
        {
          status: 409,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // 3. 二次加密密码（前端已经做了一次bcrypt）
    const finalPasswordHash = await bcrypt.hash(passwordHash)

    // 4. 创建Auth用户
    const email = `${username.toLowerCase()}@temp-chat.app`
    const randomPassword = crypto.randomUUID()

    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser(
      {
        email: email,
        password: randomPassword,
        email_confirm: true,
        user_metadata: {
          username: username,
        },
      }
    )

    if (authError || !authData.user) {
      console.error('创建Auth用户失败:', authError)
      return new Response(
        JSON.stringify({ error: '注册失败，请重试' }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    const userId = authData.user.id

    // 5. 创建用户记录
    const { error: insertError } = await supabaseAdmin.from('users').insert({
      id: userId,
      username: username,
      password_hash: finalPasswordHash,
      gender: tempData?.gender || 'male',
      avatar_url:
        tempData?.avatarUrl ||
        `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      location: tempData?.location || '未知',
      coins: 6,
      is_temp: false,
    })

    if (insertError) {
      // 回滚：删除Auth用户
      await supabaseAdmin.auth.admin.deleteUser(userId)

      console.error('创建用户记录失败:', insertError)
      return new Response(
        JSON.stringify({ error: '注册失败，请重试' }),
        {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    // 6. 如果需要迁移聊天记录（用户名未改变）
    const keepChatHistory = tempId && tempData && username === tempData.username
    if (keepChatHistory) {
      try {
        // 迁移聊天记录
        await migrateChatHistory(supabaseAdmin, tempId, userId)
      } catch (migrationError) {
        console.error('迁移聊天记录失败:', migrationError)
        // 不影响注册流程，只记录错误
      }
    }

    // 7. 删除临时用户的在线状态
    if (tempId) {
      await supabaseAdmin.from('online_users').delete().eq('id', tempId)
    }

    // 8. 创建在线用户记录
    await supabaseAdmin.from('online_users').insert({
      id: userId,
      is_online: true,
      last_seen: new Date().toISOString(),
    })

    // 9. 生成访问token
    const { data: sessionData, error: sessionError } =
      await supabaseAdmin.auth.admin.generateLink({
        type: 'magiclink',
        email: email,
      })

    // 10. 返回成功
    return new Response(
      JSON.stringify({
        success: true,
        user: {
          id: userId,
          username: username,
          coins: 6,
        },
        // 注意：生产环境应该发送magic link到邮箱
        // 这里简化处理，直接返回token
        message: '注册成功！已赠送6金币',
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('注册错误:', error)
    return new Response(
      JSON.stringify({
        error: '服务器内部错误',
        message: error.message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})

// 迁移聊天记录函数
async function migrateChatHistory(
  supabaseAdmin: any,
  oldTempId: string,
  newUserId: string
) {
  // 1. 查找包含旧临时ID的所有聊天
  const { data: messages, error: fetchError } = await supabaseAdmin
    .from('messages')
    .select('*')
    .or(`sender_id.eq.${oldTempId},receiver_id.eq.${oldTempId}`)

  if (fetchError || !messages || messages.length === 0) {
    return
  }

  // 2. 更新消息中的用户ID
  for (const message of messages) {
    const updates: any = {}

    if (message.sender_id === oldTempId) {
      updates.sender_id = newUserId
    }

    if (message.receiver_id === oldTempId) {
      updates.receiver_id = newUserId
    }

    // 更新chat_id
    const oldChatId = message.chat_id
    const otherUserId =
      message.sender_id === oldTempId ? message.receiver_id : message.sender_id
    const newChatId = [newUserId, otherUserId].sort().join('_')

    if (newChatId !== oldChatId) {
      updates.chat_id = newChatId
    }

    if (Object.keys(updates).length > 0) {
      await supabaseAdmin.from('messages').update(updates).eq('id', message.id)
    }
  }

  // 3. 迁移消息计数
  const { data: counts } = await supabaseAdmin
    .from('message_counts')
    .select('*')
    .or(`user_id.eq.${oldTempId},target_user_id.eq.${oldTempId}`)

  if (counts && counts.length > 0) {
    for (const count of counts) {
      const updates: any = {}

      if (count.user_id === oldTempId) {
        updates.user_id = newUserId
      }

      if (count.target_user_id === oldTempId) {
        updates.target_user_id = newUserId
      }

      if (Object.keys(updates).length > 0) {
        // 删除旧记录
        await supabaseAdmin
          .from('message_counts')
          .delete()
          .eq('user_id', count.user_id)
          .eq('target_user_id', count.target_user_id)

        // 插入新记录（可能存在冲突，使用upsert）
        await supabaseAdmin
          .from('message_counts')
          .upsert({
            user_id: updates.user_id || count.user_id,
            target_user_id: updates.target_user_id || count.target_user_id,
            count: count.count,
          })
      }
    }
  }

  console.log(`聊天记录迁移完成: ${oldTempId} -> ${newUserId}`)
}
